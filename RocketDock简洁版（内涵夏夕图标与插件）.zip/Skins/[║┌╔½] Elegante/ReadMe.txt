__________________________________________________
|		Elegante Dockbar for Rocketdock   		  |
|	Created by Zachary Monk (Zmonk91@gmail.com)	  |
|_________________________________________________|

Installation:
1) Unzip to your default Rocketdock Theme Folder (C:\Program Files (x86)\RocketDock\Skins)
2) Open Dock Settings > Style > Theme > Select Elegante > Press OK


To use a different color option - 

Dockbar Background:
1) Open the Background.ini file (C:\Program Files (x86)\RocketDock\Skins\Elegante\Background.ini)
2) Change the default ('Bg.png') to the option you prefer   i.e. 'Bg-Gold-Thin.png'
3) Save the file
4) Go to Dock Settings, change the theme to any different theme
5) Change theme back to Elegante to refresh the file

Dockbar Seperators:
1) Open the Seperator.ini file (C:\Program Files (x86)\RocketDock\Skins\Elegante\Seperator.ini)
2) Change the default ('Seperator.png') to the option you prefer   i.e. 'Seperator-Gold.png'
3) Save the file
4) Go to Dock Settings, change the theme to any different theme
5) Change theme back to Elegante to refresh the file

* NOTE * 
All Background images are saved with the prefix 'Bg' in the file name.
All Seperator images are saved with the prefix 'Seperator' in the file name.

For requests, just email me or shoot me a comment on DeviantArt. 
 
Feel free to modify, edit, and change anything you want to. 