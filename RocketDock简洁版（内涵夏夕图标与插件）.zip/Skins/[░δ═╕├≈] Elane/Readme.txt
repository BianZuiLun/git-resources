Yeah. Here's your read me.






Uhh....





Mhmm...





To install this skin, extract the contents to C:\Program Files\Rocektdock\Skins (program files x86 for 64 bit users) then go to dock settings and choose minimal from styles.
Thanks to HackThePlanet24 for typing that out for me.


That's all folks!